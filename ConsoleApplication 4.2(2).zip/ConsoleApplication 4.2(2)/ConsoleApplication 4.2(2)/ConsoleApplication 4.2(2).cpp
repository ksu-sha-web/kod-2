﻿#include <iostream>
#include <vector>

int main() {
    setlocale(LC_ALL, "RU");
    int size;
    std::cout << "Введите размерность двумерного массива: ";
    std::cin >> size;

    std::vector<std::vector<int>> matrix(size, std::vector<int>(size));

    // Ввод элементов двумерного массива
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            std::cout << "Введите элемент [" << i << "][" << j << "]: ";
            std::cin >> matrix[i][j];
        }
    }

    // Вывод двумерного массива
    std::cout << "Двумерный массив:\n";
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << "\n";
    }

    // Вычисление суммы чисел, находящихся по диагонали массива
    int sum_diagonal = 0;
    for (int i = 0; i < size; ++i) {
        sum_diagonal += matrix[i][i];
    }

    std::cout << "Сумма чисел по диагонали: " << sum_diagonal << std::endl;

    return 0;
}